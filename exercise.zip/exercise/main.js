let cars = [
    {
        make: 'Honda',
        model: 'CRV',
        color: 'Green',
        miles: 5000
    },
    {
        make: 'Honda',
        model: 'Accord',
        color: 'Blue',
        miles: 10000
    },
    {
        make: 'Toyota',
        model: 'Prius',
        color: 'Silver',
        miles: 0
    }
]